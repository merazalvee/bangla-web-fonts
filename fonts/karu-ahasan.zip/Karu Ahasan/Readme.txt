Thank you for download our font.

You are expressly and emphatically restricted from all of the following:-

1. You can�t sell the fonts available on FontBD
2. You can�t download them and upload on your website without our consent or proper legal permission.
3. You can't change the font information, sell or distribute them as your own creation or intellectual property.
3. You can't use the font like a webfont.

If You've purchased the font from anyone, share his/her contact details with us, we will take legal step againt the fraud.